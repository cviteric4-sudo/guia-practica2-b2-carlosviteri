from datetime import date
import re
from models import Estudiante, Materia, Matricula
from shared.json_manager import GestorJSON

gestor_estudiantes = GestorJSON("data/estudiantes.json")
gestor_materias = GestorJSON("data/materias.json")
gestor_matriculas = GestorJSON("data/matriculas.json")


def leer_objetos(gestor, clase):
    return [clase.desde_diccionario(d) for d in gestor.leer()]


def obtener_por_id(objetos, id_registro):
    return next((obj for obj in objetos if obj.id == int(id_registro)), None)


def buscar(objetos, termino, campos):
    termino = termino.strip().lower()
    return [obj for obj in objetos if any(termino in str(getattr(obj, c, "")).lower() for c in campos)]


def siguiente_id(gestor):
    datos = gestor.leer()
    return max((int(d.get("id", 0)) for d in datos), default=0) + 1


def guardar_nuevo(gestor, objeto):
    datos = gestor.leer()
    datos.append(objeto.a_diccionario())
    return gestor.guardar(datos)


def reemplazar(gestor, objeto):
    datos = gestor.leer()
    for i, dato in enumerate(datos):
        if int(dato.get("id", -1)) == objeto.id:
            datos[i] = objeto.a_diccionario()
            return gestor.guardar(datos)
    return False


def eliminar(gestor, id_registro):
    datos = [d for d in gestor.leer() if int(d.get("id", -1)) != int(id_registro)]
    return gestor.guardar(datos)


def ids_registrados(objetos, campo):
    return {getattr(obj, campo).lower() for obj in objetos}


def indice_por_id(objetos):
    return {obj.id: obj for obj in objetos}


def obtener_estudiantes():
    return leer_objetos(gestor_estudiantes, Estudiante)


def obtener_estudiante(id_estudiante):
    return obtener_por_id(obtener_estudiantes(), id_estudiante)


def buscar_estudiantes(termino):
    return buscar(obtener_estudiantes(), termino, ("nombre", "apellido", "email", "carnet", "carrera"))


def crear_estudiante(datos):
    requeridos = ("nombre", "apellido", "email", "carnet")
    if any(not str(datos.get(c, "")).strip() for c in requeridos):
        return False, "Nombre, apellido, email y carnet son obligatorios."
    email = str(datos["email"]).strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        return False, "El email no tiene un formato válido."
    estudiantes = obtener_estudiantes()
    if email in ids_registrados(estudiantes, "email"):
        return False, "Ese email ya está registrado."
    if str(datos["carnet"]).strip().lower() in ids_registrados(estudiantes, "carnet"):
        return False, "Ese carnet ya está registrado."
    obj = Estudiante(siguiente_id(gestor_estudiantes), datos["nombre"], datos["apellido"],
                     email, datos["carnet"], datos.get("carrera", ""))
    return (True, obj) if guardar_nuevo(gestor_estudiantes, obj) else (False, "No se pudo guardar.")


def actualizar_estudiante(id_estudiante, cambios):
    obj = obtener_estudiante(id_estudiante)
    if obj is None:
        return False, "No se encontró el estudiante."
    datos = obj.a_diccionario()
    datos.update(cambios)
    datos["id"] = obj.id
    todos = obtener_estudiantes()
    for otro in todos:
        if otro.id != obj.id and otro.email == str(datos["email"]).strip().lower():
            return False, "Ese email ya está registrado."
        if otro.id != obj.id and otro.carnet == str(datos["carnet"]).strip().upper():
            return False, "Ese carnet ya está registrado."
    actualizado = Estudiante(obj.id, datos["nombre"], datos["apellido"], datos["email"],
                             datos["carnet"], datos.get("carrera", ""))
    return (True, actualizado) if reemplazar(gestor_estudiantes, actualizado) else (False, "No se pudo actualizar.")


def eliminar_estudiante(id_estudiante):
    if obtener_estudiante(id_estudiante) is None:
        return False, "No se encontró el estudiante."
    if any(m.estudiante_id == int(id_estudiante) for m in obtener_matriculas()):
        return False, "No se puede eliminar: el estudiante tiene matrículas. Retíralas primero."
    return (True, "Estudiante eliminado.") if eliminar(gestor_estudiantes, id_estudiante) else (False, "No se pudo eliminar.")


def obtener_materias():
    return leer_objetos(gestor_materias, Materia)


def obtener_materia(id_materia):
    return obtener_por_id(obtener_materias(), id_materia)


def buscar_materias(termino):
    return buscar(obtener_materias(), termino, ("nombre", "codigo"))


def crear_materia(datos):
    if not str(datos.get("nombre", "")).strip() or not str(datos.get("codigo", "")).strip():
        return False, "Nombre y código son obligatorios."
    try:
        creditos, cupos = int(datos.get("creditos", 1)), int(datos.get("cupos", 0))
    except (TypeError, ValueError):
        return False, "Créditos y cupos deben ser números enteros."
    if not 1 <= creditos <= 10:
        return False, "Los créditos deben estar entre 1 y 10."
    if not 0 <= cupos <= Materia.CUPOS_MAXIMOS:
        return False, f"Los cupos deben estar entre 0 y {Materia.CUPOS_MAXIMOS}."
    materias = obtener_materias()
    if str(datos["codigo"]).strip().lower() in ids_registrados(materias, "codigo"):
        return False, "Ese código ya existe."
    obj = Materia(siguiente_id(gestor_materias), datos["nombre"], datos["codigo"], creditos, cupos)
    return (True, obj) if guardar_nuevo(gestor_materias, obj) else (False, "No se pudo guardar la materia.")


def actualizar_materia(id_materia, cambios):
    obj = obtener_materia(id_materia)
    if obj is None:
        return False, "No se encontró la materia."
    datos = obj.a_diccionario()
    datos.update(cambios)
    try:
        creditos, cupos = int(datos["creditos"]), int(datos["cupos"])
    except (ValueError, TypeError, KeyError):
        return False, "Créditos y cupos deben ser números enteros."
    if not 1 <= creditos <= 10 or not 0 <= cupos <= Materia.CUPOS_MAXIMOS:
        return False, "Créditos deben ser 1-10 y cupos 0-30."
    for otro in obtener_materias():
        if otro.id != obj.id and otro.codigo == str(datos["codigo"]).strip().upper():
            return False, "Ese código ya existe."
    actualizado = Materia(obj.id, datos["nombre"], datos["codigo"], creditos, cupos)
    return (True, actualizado) if reemplazar(gestor_materias, actualizado) else (False, "No se pudo actualizar.")


def eliminar_materia(id_materia):
    if obtener_materia(id_materia) is None:
        return False, "No se encontró la materia."
    if any(m.materia_id == int(id_materia) for m in obtener_matriculas()):
        return False, "No se puede eliminar: tiene matrículas asociadas."
    return (True, "Materia eliminada.") if eliminar(gestor_materias, id_materia) else (False, "No se pudo eliminar.")


def materias_sin_cupo():
    return [m for m in obtener_materias() if not m.hay_cupo()]


def obtener_matriculas():
    return leer_objetos(gestor_matriculas, Matricula)


def obtener_matricula(id_matricula):
    return obtener_por_id(obtener_matriculas(), id_matricula)


def crear_matricula(datos):
    try:
        estudiante_id, materia_id = int(datos["estudiante_id"]), int(datos["materia_id"])
    except (ValueError, TypeError, KeyError):
        return False, "Debes indicar IDs válidos de estudiante y materia."
    estudiante, materia = obtener_estudiante(estudiante_id), obtener_materia(materia_id)
    if estudiante is None:
        return False, "El estudiante no existe."
    if materia is None:
        return False, "La materia no existe."
    if not materia.hay_cupo():
        return False, "La materia no tiene cupos disponibles."
    periodo = str(datos.get("periodo", "")).strip()
    if not periodo:
        return False, "El periodo es obligatorio."
    for m in obtener_matriculas():
        if m.estudiante_id == estudiante_id and m.materia_id == materia_id and m.periodo.lower() == periodo.lower():
            return False, "El estudiante ya está matriculado en esa materia y periodo."
    materia.ocupar_cupo()
    if not reemplazar(gestor_materias, materia):
        return False, "No se pudo actualizar el cupo."
    obj = Matricula(siguiente_id(gestor_matriculas), estudiante_id, materia_id, periodo,
                    None, str(datos.get("fecha", date.today().isoformat())))
    if guardar_nuevo(gestor_matriculas, obj):
        return True, obj
    materia.liberar_cupo()
    reemplazar(gestor_materias, materia)
    return False, "No se pudo guardar la matrícula."


def registrar_nota(id_matricula, nota):
    obj = obtener_matricula(id_matricula)
    if obj is None:
        return False, "No se encontró la matrícula."
    if not Materia.es_nota_valida(nota):
        return False, "La nota debe estar entre 0 y 20."
    datos = obj.a_diccionario()
    datos["nota"] = float(nota)
    actualizado = Matricula.desde_diccionario(datos)
    return (True, actualizado) if reemplazar(gestor_matriculas, actualizado) else (False, "No se pudo guardar la nota.")


def retirar_matricula(id_matricula):
    obj = obtener_matricula(id_matricula)
    if obj is None:
        return False, "No se encontró la matrícula."
    materia = obtener_materia(obj.materia_id)
    if materia:
        materia.liberar_cupo()
        reemplazar(gestor_materias, materia)
    return (True, obj) if eliminar(gestor_matriculas, id_matricula) else (False, "No se pudo retirar la matrícula.")


def certificado(id_matricula):
    matricula = obtener_matricula(id_matricula)
    if matricula is None:
        return False, "No se encontró la matrícula."
    estudiante = obtener_estudiante(matricula.estudiante_id)
    materia = obtener_materia(matricula.materia_id)
    if not estudiante or not materia:
        return False, "Faltan datos del estudiante o de la materia."
    nota_texto = "Sin nota" if matricula.nota is None else f"{matricula.nota:g}"
    texto = (
        f"CERTIFICADO #{matricula.id}   Periodo: {matricula.periodo}\n"
        f"Estudiante: {estudiante.nombre_completo()} ({estudiante.carnet})\n"
        f"Materia: {materia.nombre} ({materia.codigo}) · {materia.creditos} créditos\n"
        f"Nota: {nota_texto}\n"
        f"Estado: {matricula.estado()}"
    )
    return True, texto


def matriculas_por_estudiante():
    resultado = {}
    for matricula in obtener_matriculas():
        resultado.setdefault(matricula.estudiante_id, []).append(matricula)
    return resultado


def promedio_de_estudiante(id_estudiante):
    if obtener_estudiante(id_estudiante) is None:
        return False, "No se encontró el estudiante."
    notas = [m.nota for m in obtener_matriculas()
             if m.estudiante_id == int(id_estudiante) and m.nota is not None]
    return True, round(sum(notas) / len(notas), 2) if notas else 0


def mostrar_lista(objetos):
    # Polimorfismo: imprime objetos de Estudiante, Materia o Matricula igual.
    for objeto in objetos:
        print(objeto)
