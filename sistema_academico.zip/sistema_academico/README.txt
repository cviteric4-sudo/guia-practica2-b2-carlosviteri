SISTEMA ACADEMICO - Python 3

Estructura:
- main.py: menú / vista de consola
- views.py: controlador y operaciones CRUD
- models.py: ModeloBase, Persona, Estudiante, Materia y Matricula
- shared/json_manager.py: lectura y escritura JSON
- data/*.json: datos persistentes

Ejecutar:
1. Descomprime la carpeta.
2. Abre PowerShell dentro de la carpeta sistema_academico.
3. Ejecuta: python main.py
   Si el comando python no funciona en Windows, instala Python 3 desde python.org y marca
   "Add Python to PATH". Luego abre una terminal nueva.

Herencia:
Estudiante hereda de Persona; Persona, Materia y Matricula heredan de ModeloBase.
Polimorfismo:
main.py llama mostrar_lista(objetos), que imprime cualquier modelo; __str__ de ModeloBase
llama etiqueta(), sobrescrito por cada modelo.
JSON:
El sistema usa tres archivos separados para estudiantes, materias y matrículas.
