class ModeloBase:
    """Clase padre: concentra el id, la serialización y el comportamiento común."""

    def __init__(self, id_registro):
        self.id = int(id_registro)

    def a_diccionario(self):
        return {"id": self.id}

    @classmethod
    def desde_diccionario(cls, datos):
        datos = dict(datos)
        id_registro = datos.pop("id")
        return cls(id_registro, **datos)

    def etiqueta(self):
        return f"Registro {self.id}"

    def __str__(self):
        # Polimorfismo: etiqueta() depende de la clase concreta del objeto.
        return f"[{self.id}] {self.etiqueta()}"


class Persona(ModeloBase):
    def __init__(self, id_registro, nombre, apellido, email):
        super().__init__(id_registro)
        self.nombre = nombre.strip()
        self.apellido = apellido.strip()
        self.email = email.strip().lower()

    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos.update({
            "nombre": self.nombre,
            "apellido": self.apellido,
            "email": self.email,
        })
        return datos

    def etiqueta(self):
        return self.nombre_completo()


class Estudiante(Persona):
    def __init__(self, id_registro, nombre, apellido, email, carnet="", carrera=""):
        super().__init__(id_registro, nombre, apellido, email)
        self.carnet = carnet.strip().upper()
        self.carrera = carrera.strip()

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos.update({"carnet": self.carnet, "carrera": self.carrera})
        return datos

    def etiqueta(self):
        return f"{super().etiqueta()} · {self.carnet} · {self.carrera or 'Sin carrera'}"


class Materia(ModeloBase):
    CUPOS_MAXIMOS = 30
    NOTA_APROBACION = 14

    def __init__(self, id_registro, nombre, codigo, creditos=1, cupos=0):
        super().__init__(id_registro)
        self.nombre = nombre.strip()
        self.codigo = codigo.strip().upper()
        self.creditos = int(creditos)
        self.cupos = int(cupos)

    @staticmethod
    def es_nota_valida(valor):
        try:
            return 0 <= float(valor) <= 20
        except (TypeError, ValueError):
            return False

    def hay_cupo(self):
        return self.cupos > 0

    def ocupar_cupo(self):
        if not self.hay_cupo():
            return False
        self.cupos -= 1
        return True

    def liberar_cupo(self):
        if self.cupos < self.CUPOS_MAXIMOS:
            self.cupos += 1

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos.update({
            "nombre": self.nombre, "codigo": self.codigo,
            "creditos": self.creditos, "cupos": self.cupos,
        })
        return datos

    def etiqueta(self):
        return f"{self.nombre} · {self.codigo} · {self.creditos} créditos · {self.cupos} cupos"


class Matricula(ModeloBase):
    def __init__(self, id_registro, estudiante_id, materia_id, periodo, nota=None, fecha=""):
        super().__init__(id_registro)
        self.estudiante_id = int(estudiante_id)
        self.materia_id = int(materia_id)
        self.periodo = periodo.strip()
        self.nota = None if nota in (None, "") else float(nota)
        self.fecha = fecha.strip()

    def esta_aprobada(self):
        return self.nota is not None and self.nota >= Materia.NOTA_APROBACION

    def estado(self):
        if self.nota is None:
            return "Pendiente"
        return "Aprobado" if self.esta_aprobada() else "Reprobado"

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos.update({
            "estudiante_id": self.estudiante_id,
            "materia_id": self.materia_id,
            "periodo": self.periodo,
            "nota": self.nota,
            "fecha": self.fecha,
        })
        return datos

    def etiqueta(self):
        nota = "Sin nota" if self.nota is None else f"Nota {self.nota:g}"
        return f"Estudiante #{self.estudiante_id} · Materia #{self.materia_id} · {self.periodo} · {nota} · {self.estado()}"
