from views import (
    crear_estudiante, obtener_estudiantes, obtener_estudiante, buscar_estudiantes,
    actualizar_estudiante, eliminar_estudiante, crear_materia, obtener_materias,
    buscar_materias, actualizar_materia, eliminar_materia, materias_sin_cupo,
    crear_matricula, obtener_matriculas, registrar_nota, retirar_matricula,
    certificado, promedio_de_estudiante, mostrar_lista
)


def pausa():
    input("\nPresiona ENTER para continuar...")


def pedir_id(mensaje):
    try:
        return int(input(mensaje))
    except ValueError:
        print("El ID debe ser un número entero.")
        return None


def menu_estudiantes():
    while True:
        print("\n--- ESTUDIANTES ---\n1. Crear\n2. Listar\n3. Buscar\n4. Actualizar\n5. Eliminar\n0. Volver")
        op = input("Opción: ").strip()
        if op == "1":
            datos = {
                "nombre": input("Nombre: "), "apellido": input("Apellido: "),
                "email": input("Email: "), "carnet": input("Carnet: "),
                "carrera": input("Carrera: "),
            }
            ok, info = crear_estudiante(datos)
            print("Correcto:" if ok else "Error:", info)
            pausa()
        elif op == "2":
            mostrar_lista(obtener_estudiantes()); pausa()
        elif op == "3":
            mostrar_lista(buscar_estudiantes(input("Buscar por nombre, apellido, email, carnet o carrera: "))); pausa()
        elif op == "4":
            ident = pedir_id("ID a actualizar: ")
            obj = obtener_estudiante(ident) if ident is not None else None
            if not obj:
                print("No existe ese estudiante.")
            else:
                cambios = {}
                for campo in ("nombre", "apellido", "email", "carnet", "carrera"):
                    actual = getattr(obj, campo)
                    nuevo = input(f"{campo.capitalize()} [{actual}]: ").strip()
                    cambios[campo] = nuevo or actual
                ok, info = actualizar_estudiante(ident, cambios)
                print("Correcto:" if ok else "Error:", info)
            pausa()
        elif op == "5":
            ident = pedir_id("ID a eliminar: ")
            if ident is not None:
                ok, info = eliminar_estudiante(ident)
                print("Correcto:" if ok else "Error:", info)
            pausa()
        elif op == "0":
            return
        else:
            print("Opción no válida.")


def menu_materias():
    while True:
        print("\n--- MATERIAS ---\n1. Crear\n2. Listar\n3. Buscar\n4. Actualizar\n5. Eliminar\n6. Materias sin cupo\n0. Volver")
        op = input("Opción: ").strip()
        if op == "1":
            try:
                creditos = int(input("Créditos (1-10): "))
                cupos = int(input("Cupos (0-30): "))
            except ValueError:
                print("Créditos y cupos deben ser enteros."); pausa(); continue
            ok, info = crear_materia({"nombre": input("Nombre: "), "codigo": input("Código: "),
                                      "creditos": creditos, "cupos": cupos})
            print("Correcto:" if ok else "Error:", info); pausa()
        elif op == "2":
            mostrar_lista(obtener_materias()); pausa()
        elif op == "3":
            mostrar_lista(buscar_materias(input("Buscar por nombre o código: "))); pausa()
        elif op == "4":
            ident = pedir_id("ID a actualizar: ")
            if ident is not None:
                from views import obtener_materia
                obj = obtener_materia(ident)
                if not obj:
                    print("No existe esa materia.")
                else:
                    nombre = input(f"Nombre [{obj.nombre}]: ").strip() or obj.nombre
                    codigo = input(f"Código [{obj.codigo}]: ").strip() or obj.codigo
                    try:
                        creditos = int(input(f"Créditos [{obj.creditos}]: ") or obj.creditos)
                        cupos = int(input(f"Cupos [{obj.cupos}]: ") or obj.cupos)
                        ok, info = actualizar_materia(ident, {"nombre": nombre, "codigo": codigo,
                                                               "creditos": creditos, "cupos": cupos})
                        print("Correcto:" if ok else "Error:", info)
                    except ValueError:
                        print("Créditos y cupos deben ser enteros.")
            pausa()
        elif op == "5":
            ident = pedir_id("ID a eliminar: ")
            if ident is not None:
                ok, info = eliminar_materia(ident); print("Correcto:" if ok else "Error:", info)
            pausa()
        elif op == "6":
            mostrar_lista(materias_sin_cupo()); pausa()
        elif op == "0":
            return
        else:
            print("Opción no válida.")


def menu_matriculas():
    while True:
        print("\n--- MATRÍCULAS ---\n1. Crear matrícula\n2. Listar\n3. Registrar nota\n4. Ver certificado\n5. Retirar matrícula\n6. Promedio por estudiante\n0. Volver")
        op = input("Opción: ").strip()
        if op == "1":
            try:
                estudiante_id = int(input("ID estudiante: "))
                materia_id = int(input("ID materia: "))
            except ValueError:
                print("Los IDs deben ser enteros."); pausa(); continue
            periodo = input("Periodo (ej. 2026-1): ")
            ok, info = crear_matricula({"estudiante_id": estudiante_id, "materia_id": materia_id,
                                        "periodo": periodo})
            print("Correcto:" if ok else "Error:", info); pausa()
        elif op == "2":
            mostrar_lista(obtener_matriculas()); pausa()
        elif op == "3":
            ident = pedir_id("ID de matrícula: ")
            if ident is not None:
                try:
                    nota = float(input("Nota (0-20): "))
                    ok, info = registrar_nota(ident, nota)
                    print("Correcto:" if ok else "Error:", info)
                except ValueError:
                    print("La nota debe ser numérica.")
            pausa()
        elif op == "4":
            ident = pedir_id("ID de matrícula para el certificado: ")
            if ident is not None:
                ok, info = certificado(ident); print(info)
            pausa()
        elif op == "5":
            ident = pedir_id("ID de matrícula a retirar: ")
            if ident is not None:
                ok, info = retirar_matricula(ident); print("Correcto:" if ok else "Error:", info)
            pausa()
        elif op == "6":
            ident = pedir_id("ID de estudiante: ")
            if ident is not None:
                ok, info = promedio_de_estudiante(ident)
                print(f"Promedio: {info}" if ok else f"Error: {info}")
            pausa()
        elif op == "0":
            return
        else:
            print("Opción no válida.")


def main():
    while True:
        print("\n" + "=" * 45 + "\n SISTEMA ACADÉMICO\n" + "=" * 45)
        print("1. Estudiantes\n2. Materias\n3. Matrículas\n0. Salir")
        op = input("Selecciona una opción: ").strip()
        if op == "1":
            menu_estudiantes()
        elif op == "2":
            menu_materias()
        elif op == "3":
            menu_matriculas()
        elif op == "0":
            print("Programa terminado."); break
        else:
            print("Opción no válida.")


if __name__ == "__main__":
    main()
